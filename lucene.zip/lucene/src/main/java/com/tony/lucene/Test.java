package com.tony.lucene;

import java.nio.file.Path;

import org.apache.log4j.Logger;



public class Test {
	private static Logger log = Logger.getLogger(Test.class);
	
	public static void main(String[] args) throws Exception {
		log.info("test");		
//		Path p = Paths.get("/a","b","c");
//		Files.createDirectories(p);
//		System.out.println(p.toAbsolutePath().toString());		
		String docPath = "C:/workspaces/BNS/zz_log/MAT_Logs/Logs1PV";
		Indexer.createIndex(docPath,true);
		Path indexPath = Indexer.getIndexPath(docPath, null);
		if(indexPath==null)return;
		Searcher.search("S3420134", indexPath.toString());
	}

}
