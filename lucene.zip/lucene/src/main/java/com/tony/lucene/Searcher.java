package com.tony.lucene;

import java.io.IOException;
import java.nio.file.Paths;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;

public class Searcher {
	private static Logger log = Logger.getLogger(Indexer.class);

	public static void search(String find, String indexUrl) {
		IndexReader reader = null;
		try {
			reader = DirectoryReader.open(FSDirectory.open(Paths.get(indexUrl)));
			IndexSearcher searcher = new IndexSearcher(reader);
			Analyzer analyzer = new StandardAnalyzer();			
			QueryParser parser = new QueryParser(LuceneConstants.FIELD_CONTENTS, analyzer);
			find = find.trim();
			Query query = parser.parse(find);
			// searcher.search(query, 100);
			TopDocs results = searcher.search(query, 10000);
			ScoreDoc[] hits = results.scoreDocs;

			int numTotalHits = Math.toIntExact(results.totalHits);
			log.info(numTotalHits + " total matching documents");

			int start = 0;
			int end = Math.min(numTotalHits, 10000);
			for (int i = start; i < end; i++) {
				Document doc = searcher.doc(hits[i].doc);				
				String path = doc.get(LuceneConstants.FIELD_PATH);
				if (path != null) {
					log.info((i + 1) + ". " + path);					
				} else {
					log.info((i + 1) + ". " + "No path for this document");
				}

			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		} finally {
			if(reader!=null)
				try {
					reader.close();
				} catch (IOException e) {					
					e.printStackTrace();
				}
		}

	}
}
