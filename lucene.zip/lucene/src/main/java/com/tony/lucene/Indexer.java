package com.tony.lucene;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.LongPoint;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class Indexer {
	private static Logger log = Logger.getLogger(Indexer.class);

	public static void createIndex(String folder) {
		createIndex(folder, false);
	}

	public static void createIndex(String folder, boolean createNew) {
		createIndex(folder, createNew, null);
	}

	public static void createIndex(String docFolder, boolean createNew, String indexFolder) {
		if (docFolder == null)
			return;
		Path docPath = Paths.get(docFolder);
		if (!Files.exists(docPath))
			return;
		Path indexPath = getIndexPath(docFolder, indexFolder);		
		if (Files.exists(indexPath))
			try {
				Files.createDirectories(indexPath);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		if (!Files.isReadable(docPath))
			throw new RuntimeException(String.format("Document directory '%s' does not exist or is not readable",
					docPath.toAbsolutePath()));

		Analyzer analyzer = new StandardAnalyzer();
		IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
		if (createNew)
			iwc.setOpenMode(OpenMode.CREATE);
		else
			iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
		IndexWriter writer = null;
		try {
			Directory dir = FSDirectory.open(indexPath);
			writer = new IndexWriter(dir, iwc);
			indexDocs(writer, docPath);
			
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if(writer!=null)
				try {
					writer.close();
				} catch (IOException e) {				
					e.printStackTrace();
				} 
		}
	}

	private static void indexDocs(final IndexWriter writer, Path path) throws IOException {
		if (Files.isDirectory(path)) {
			Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
					try {
						indexDoc(writer, file, attrs.lastModifiedTime().toMillis());
					} catch (IOException ignore) {
//						log.error(String.format("Create index for the doc %s fail!", file.toAbsolutePath().toString()),ignore);
					}
					return FileVisitResult.CONTINUE;
				}
			});
		} else {
			indexDoc(writer, path, Files.getLastModifiedTime(path).toMillis());
		}
	}

	private static void indexDoc(IndexWriter writer, Path file, long lastModified) throws IOException {
		try (InputStream stream = Files.newInputStream(file)) {
			Document doc = new Document();
			Field pathField = new StringField(LuceneConstants.FIELD_PATH, file.toString(), Field.Store.YES);
			doc.add(pathField);
			doc.add(new LongPoint(LuceneConstants.FIELD_MODIFIED, lastModified));
			doc.add(new TextField(LuceneConstants.FIELD_CONTENTS,
					new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))));
			if (writer.getConfig().getOpenMode() == OpenMode.CREATE) {
				log.info("creating index for the file " + file);
				writer.addDocument(doc);
			} else {
				log.info("updating index for the file " + file);
				writer.updateDocument(new Term(LuceneConstants.FIELD_PATH, file.toString()), doc);
			}
		}
	}
	
	public static Path getIndexPath(String docFolder, String indexFolder) {		
		Path indexPath = null;		
		if (indexFolder == null) {
			if(docFolder==null)return null;			
			Path docPath = Paths.get(docFolder);
			if (Files.isDirectory(docPath)) {
				indexPath = Paths.get(docPath.toAbsolutePath().toString(), LuceneConstants.DEFAULT_INDEX_FOLDER);
			} else {
				indexPath = Paths.get(docPath.getParent().toAbsolutePath().toString(),
						LuceneConstants.DEFAULT_INDEX_FOLDER);
			}
		} else {
			indexPath = Paths.get(indexFolder);
			if (!Files.isDirectory(indexPath))
				throw new RuntimeException("The index folder %s should be a dicrectory instead of a file");
		}
		return indexPath;
	}

}
