package com.tony.lucene;

public class LuceneConstants {
	   public static final String DEFAULT_INDEX_FOLDER="index";
	   public static final String FIELD_CONTENTS="contents";
	   public static final String FIELD_MODIFIED="modified";
	   public static final String FIELD_PATH="path";
	   public static final String FILE_NAME="filename";
	   public static final String FILE_PATH="filepath";
	   public static final int MAX_SEARCH = 10;
}
