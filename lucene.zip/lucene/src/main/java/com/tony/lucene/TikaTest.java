package com.tony.lucene;

import java.io.InputStream;

import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.sax.ToXMLContentHandler;
import org.xml.sax.ContentHandler;

public class TikaTest {

	public static void main(String[] args) throws Exception{
		 ContentHandler handler = new ToXMLContentHandler();
        InputStream stream = TikaTest.class.getResourceAsStream("test.doc");
        AutoDetectParser parser = new AutoDetectParser();
        Metadata metadata = new Metadata();
        try {
            parser.parse(stream, handler, metadata);
            System.out.println(handler.toString());
        } finally {
            stream.close();
        }

	}

}
